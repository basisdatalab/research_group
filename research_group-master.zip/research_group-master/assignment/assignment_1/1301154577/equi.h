#ifndef EQUI_H_INCLUDED
#define EQUI_H_INCLUDED
#include <iostream>
#include <stdio.h>
using namespace std;

void input(int n, int arr[]);
void equi(int n, int arr[]);

#endif // EQUI_H_INCLUDED
