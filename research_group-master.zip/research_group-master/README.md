<img src="https://raw.githubusercontent.com/afnizarnur/research_group/master/Anti%20Riset%20Riset%20Group.png" width="350">

# Research Group
Assignment, source code, and research material for database research group 2017

## Welcome
Hello guys welcome to Anti Research Research Group Database repository. Here we'll learn and do our research together :D

> Aslab 2017 
